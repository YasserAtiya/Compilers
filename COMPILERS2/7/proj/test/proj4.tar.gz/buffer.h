#include <semaphore.h>

//buffer.h
typedef int buffer_item;

//Define buffer size
#define BUFFER_SIZE 5

//Semaphores containing buffer size
sem_t full;
sem_t empty;

//Define buffer functionalities
int insert_item(buffer_item item);
int remove_item(buffer_item* item);
