#include "buffer.h"
#include <stdio.h>

//Initialize buffer
buffer_item  buffer[BUFFER_SIZE] = {0};

//Function to insert item into buffer
//Puts item in first element, moves everything else over
int insert_item(buffer_item item)
{

  //counter for iterating through queue
  int i = 0;

  sem_getvalue(&full,&i);

  //insert item into buffer
  buffer[i] = item;

  //if successful return 0
  return 0;

}

//Function to remove item into buffer
//Removes item in first element, moves everything else over
int remove_item(buffer_item* item)
{

  //counter for iterating through queue
  int i = 0;

  //take item from buffer
  *item = buffer[0];


  //Push everything over an element
  for(i = 0; i < BUFFER_SIZE; i++)
  {

    buffer[i] = buffer[i+1];

    if(i == BUFFER_SIZE-1)
      break;

  }

  //if successful return 0
  return 0;
}