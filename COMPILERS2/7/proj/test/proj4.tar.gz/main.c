#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "buffer.h"
#include <stdbool.h>
#include <signal.h>
#include <unistd.h>

//Producer function
bool Produce();

//Consumer function
bool Consume();

//Signal handler
void sig_handler(int signo);

//Mutex Semaphore
pthread_mutex_t mutex;

//End program flag
bool k;

//Arg1 = Sleep before terminating
//Arg2 = Number of producer threads
//Arg3 = Number of consumer threads
int main(int argc, char* argv[])
{
  k = false;
  
  int greaterthreadnum = 0;

  //Initialize signal handler
  if(signal(SIGINT,sig_handler) == SIG_ERR)
    fprintf(stderr, "Could not catch SIGINT\n");


  //Initialize semaphores
  pthread_mutex_init(&mutex,NULL);
  sem_init(&full,0,0);
  sem_init(&empty,0,BUFFER_SIZE);

  //Check argument count
  if(argc < 4)
  {
    fprintf(stderr, "Invalid number of arguments\n");
    fprintf(stderr, "Require 3: Sleeptime producers consumers\n");
    exit(-1);
  }

  //Get command line arguments
  const int SLEEPTIME = atoi(argv[1]);
  const int PTHREADNUM = atoi(argv[2]);
  const int CTHREADNUM = atoi(argv[3]);

  //Declare arrays of producers and consumers
  pthread_t producers[PTHREADNUM];
  pthread_t consumers[CTHREADNUM];

  //Create producer(s)
  for(int i = 0; i < PTHREADNUM; i++)
    if(pthread_create(&producers[i],NULL,Produce,NULL))
      perror("");

  //Create Consumer(s)
  for(int i = 0; i < CTHREADNUM; i++)
    if(pthread_create(&consumers[i],NULL,Consume,NULL))
      perror("");

  //Determine which we have more of
  if(PTHREADNUM > CTHREADNUM)
	  greaterthreadnum = PTHREADNUM;
  else 
	  greaterthreadnum = CTHREADNUM;
  
  //Wait for close of threads using greater thread number
  for(int i = 0; i < greaterthreadnum; i++)
  {
	  //Join thread with main thread until close
	  if(i < CTHREADNUM)
		  if(pthread_join(consumers[i],NULL))
			  fprintf(stderr, "Pthread join failed\n");
	  if(i < PTHREADNUM)
		  if(pthread_join(producers[i],NULL))
			  fprintf(stderr, "Pthread join failed\n");
	  
  }
  
  //Sleep
  sleep(SLEEPTIME);
  
  //End

}

//Function for producer, infinite loop that acquires lock and prints if cabable of inserting into buffer
bool Produce()
{
	
  //Define item we are producing
  buffer_item item;
  
  //Holder for counting semaphore value
  int semvalue = 0,f,e;

  //Infinite loop for producing
  while(true)
  {

	  //Generate random number for production
	  item = rand();
	  
	  //Sleep for random amount of time(within 10 seconds)
	  sleep(item%10);

	  //Acquire the mutex lock
	  pthread_mutex_lock(&mutex);
	  
	  //Check for global quit flag
	  if(k)
	  {
		  //Release mutex lock
		  pthread_mutex_unlock(&mutex);
		  //Exit
		  pthread_exit(true);	  
	  }
	
    //Check value of empty counting semaphore
    sem_getvalue(&empty,&semvalue);
  
    sem_getvalue(&empty,&e);
    sem_getvalue(&full,&f);


	  //Try to insert into buffer if not full
    if(e > 0 && f < BUFFER_SIZE)
    {
      //Insert item
      insert_item(item);
      
      //Increment full semaphore
      sem_post(&full);

      //Decrement empty
      sem_trywait(&empty);

      //Print consumed
      printf("producer produced %d\n",item);
    }
	  
	  //Release mutex lock
	  pthread_mutex_unlock(&mutex);
  }
  
}

//Function for consumer.  Infinite loop, aquires lock, and removes from buffer if not empty.
bool Consume()
{
  //Holder variable for item to be removed
  buffer_item item;
  
  //Holder for counting semaphore
  int semvalue = 0,f,e;
  
  //Infinite loop. Aquire lock, check if buffer not empty, remove, print
  while(true)
  {
	  
	  //Sleep for random amount of time
	  sleep(item%10);

	  //Acquire the mutex lock
	  pthread_mutex_lock(&mutex);
	  
	  //Check for global kill flag
	  if(k)
	  {
      //Release mutex lock
      pthread_mutex_unlock(&mutex);

      //Exit
      pthread_exit(true);	  
	  }
	
    //Check value of full semaphore
    sem_getvalue(&full,&semvalue);
    sem_getvalue(&empty,&e);
    sem_getvalue(&full,&f);


    //Try to remove from buffer if not empty
    if(e < BUFFER_SIZE && f > 0)
    {
      //Depopulate buffer
      remove_item(&item);
      
      //Decrement full semaphore
      sem_trywait(&full);
      
      //Increment empty semaphore
      sem_post(&empty);

      //Check consumed
      if(item)
        //Print consumed
        printf("consumer consumed %d\n",item);
    }
	  
	  
	  //Release mutex lock
	  pthread_mutex_unlock(&mutex);
  }  

}

//Function that handles signals, specifically SIGINT
void sig_handler(int signo)
{
   //If detected SIGINT
  if (signo == SIGINT)
   {
      //Close all threads
      k = true;
   }
   
}


